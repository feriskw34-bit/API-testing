# Demonstrasi API Client - Pengujian API Publik

Repositori ini berisi materi, script pengujian, koleksi Postman, aplikasi web visualisasi, dan laporan lengkap untuk tugas praktikum **Demonstrasi API Client (Semester 5)** menggunakan layanan API publik [JSONPlaceholder](https://jsonplaceholder.typicode.com).

---

## 📁 Struktur Berkas

| Berkas | Deskripsi |
| :--- | :--- |
| 📄 [`LAPORAN_PENGUJIAN_API.md`](./LAPORAN_PENGUJIAN_API.md) | **Laporan Lengkap Praktikum** (Pembahasan 5 Poin Tugas, Teori Status Code, Headers, Struktur JSON, Perbandingan Uji & Tabel Dokumentasi). Siap di-copy ke Word / PDF / Slide. |
| 🌐 [`index.html`](./index.html) | **Interactive Web API Client Dashboard**: Aplikasi web visualisasi live fetch, badge status code, tab header inspector, dan dekonstruksi struktur data JSON. Cukup buka di browser (Edge/Chrome/Firefox). |
| 📮 [`jsonplaceholder_api_test_collection.json`](./jsonplaceholder_api_test_collection.json) | **Postman Collection v2.1**: Koleksi 6 skenario pengujian API yang bisa langsung di-*import* ke Postman dengan 1 kali klik. |
| ⚡ [`test-api.ps1`](./test-api.ps1) | **Script Otomatisasi PowerShell**: Menguji seluruh skenario secara instan langsung dari terminal dengan output warna-warni. |

---

## 🚀 Cara Menjalankan Pengujian

### 1. Menjalankan Lewat Postman
1. Buka aplikasi **Postman**.
2. Klik tombol **Import** di kiri atas.
3. Pilih berkas [`jsonplaceholder_api_test_collection.json`](./jsonplaceholder_api_test_collection.json).
4. Klik setiap request dan tekan **Send** untuk melihat response dan mengambil screenshot.

### 2. Menjalankan Web Dashboard
* Cukup klik dua kali (atau *drag & drop*) file [`index.html`](./index.html) ke browser Anda.
* Anda bisa memilih skenario di panel sebelah kiri lalu melihat response body, response headers, dan analisis struktur JSON secara visual.

### 3. Menjalankan Script Terminal (PowerShell)
Buka PowerShell di folder ini lalu jalankan:
```powershell
powershell -ExecutionPolicy Bypass -File .\test-api.ps1
```

---

## 📊 Ringkasan Tabel Dokumentasi Pengujian

| No | Skenario | Method | Endpoint | Status Code | Content-Type | Hasil / Observasi |
| :---: | :--- | :---: | :--- | :---: | :---: | :--- |
| 1 | Ambil 1 post | `GET` | `/posts/1` | `200 OK` | `application/json` | JSON Object dengan 4 key: `userId`, `id`, `title`, `body` |
| 2 | Ambil semua post | `GET` | `/posts` | `200 OK` | `application/json` | JSON Array berisi 100 objek postingan |
| 3 | Ambil data user | `GET` | `/users/1` | `200 OK` | `application/json` | Nested JSON Object (`address` dengan sub `geo` & `company`) |
| 4 | Buat post baru | `POST` | `/posts` | `201 Created` | `application/json` | Objek baru berhasil dibuat, server merespon dengan `id: 101` |
| 5 | ID tidak ada | `GET` | `/posts/9999` | `404 Not Found` | `application/json` | Server merespon status 404 dengan body objek kosong `{}` |
| 6 | Path salah | `GET` | `/postss/1` | `404 Not Found` | `application/json` | Endpoint tidak dikenali (routing error), status 404 |
