# LAPORAN PRAKTIKUM: DEMONSTRASI PENGUJIAN API PUBLIK (API CLIENT)

* **Mata Kuliah:** Praktikum API Client / Web Service  
* **Semester:** 5 (Lima)  
* **Target Layanan:** JSONPlaceholder (Public REST API - Free & Stable)  
* **Base URL:** `https://jsonplaceholder.typicode.com`  
* **Alat Pengujian:** Postman, cURL, Windows PowerShell, dan Web Client Tester  

---

## DAFTAR ISI
1. [Latar Belakang & Pilihan API Publik](#1-latar-belakang--pilihan-api-publik)
2. [Tugas 1: Pengiriman Request dengan HTTP Method](#2-tugas-1-pengiriman-request-dengan-http-method)
3. [Tugas 2: Identifikasi Status Code dan Response Header](#3-tugas-2-identifikasi-status-code-dan-response-header)
4. [Tugas 3: Identifikasi Struktur Data JSON (Object, Array, Key-Value)](#4-tugas-3-identifikasi-struktur-data-json-object-array-key-value)
5. [Tugas 4: Pengujian Endpoint dengan ID Tersedia vs Tidak Tersedia](#5-tugas-4-pengujian-endpoint-dengan-id-tersedia-vs-tidak-tersedia)
6. [Tugas 5: Tabel Dokumentasi Pengujian Sistematis](#6-tugas-5-tabel-dokumentasi-pengujian-sistematis)
7. [Panduan File Pendukung & Eksekusi](#7-panduan-file-pendukung--eksekusi)

---

## 1. Latar Belakang & Pilihan API Publik

Dalam arsitektur perangkat lunak modern berbasis *Service-Oriented Architecture* (SOA) dan *Microservices*, API (*Application Programming Interface*) bertindak sebagai jembatan komunikasi antar aplikasi. RESTful API memanfaatkan protokol HTTP/HTTPS untuk melakukan pertukaran data secara terstandarisasi.

Untuk praktikum ini dipilih **JSONPlaceholder** (`https://jsonplaceholder.typicode.com`) karena:
1. **Publik & Bebas Akses:** Tidak memerlukan API Key atau otentikasi token yang rumit sehingga cocok untuk demonstrasi instan.
2. **Dukungan HTTP Method Lengkap:** Mendukung operasi CRUD (*Create, Read, Update, Delete*) menggunakan method `GET`, `POST`, `PUT`, `PATCH`, dan `DELETE`.
3. **Struktur Data Representatif:** Menyediakan variasi struktur data, mulai dari entitas tunggal (*Object*), kumpulan data (*Array of Objects*), hingga data berelasi/bersarang (*Nested Objects*).
4. **Stabilitas Server Tinggi:** Dihosting di infrastruktur handal dengan proteksi Cloudflare CDN.

---

## 2. Tugas 1: Pengiriman Request dengan HTTP Method

### 2.1 Konsep HTTP Method
HTTP Method mendefinisikan aksi yang ingin dilakukan klien terhadap resource pada server:
* `GET`: Mengambil (*retrieve*) data dari server tanpa mengubah kondisi data (bersifat *idempotent* dan *safe*).
* `POST`: Mengirim data baru ke server untuk dibuatkan resource baru di database.
* `PUT`: Memperbarui seluruh data resource yang sudah ada secara menyeluruh.
* `DELETE`: Menghapus data resource tertentu dari server.

---

### 2.2 Langkah Praktik Menggunakan Postman
1. Buka aplikasi **Postman**.
2. Klik tombol **New** -> pilih **HTTP Request**.
3. Atur konfigurasi request berikut:
   * **Method:** `GET`
   * **URL Endpoint:** `https://jsonplaceholder.typicode.com/posts/1`
4. Klik tombol **Send** di sebelah kanan kolom URL.
5. Perhatikan panel bagian bawah:
   * Tab **Body**: Menampilkan hasil data yang dikembalikan server.
   * Tab **Headers**: Menampilkan metadata transmisi HTTP.
   * Bagian kanan atas panel: Menampilkan Status Code (`200 OK`), Waktu Respon (`ms`), dan Ukuran Payload (`bytes`).

---

### 2.3 Alternatif Pengujian Menggunakan cURL (Terminal)
Eksekusi di terminal / PowerShell:
```bash
curl.exe -i -s https://jsonplaceholder.typicode.com/posts/1
```
*Flag `-i` digunakan untuk menyertakan HTTP Header dalam output response.*

**Hasil Output Terminal:**
```http
HTTP/1.1 200 OK
Date: Sat, 24 Oct 2026 12:32:55 GMT
Content-Type: application/json; charset=utf-8
Content-Length: 292
Server: cloudflare

{
  "userId": 1,
  "id": 1,
  "title": "sunt aut facere repellat provident occaecati excepturi optio reprehenderit",
  "body": "quia et suscipit\nsuscipit recusandae consequuntur..."
}
```

---

### 2.4 Demonstrasi Method POST (Membuat Data Baru)
* **Endpoint:** `https://jsonplaceholder.typicode.com/posts`
* **Method:** `POST`
* **Headers:** `Content-Type: application/json`
* **Request Body (raw JSON):**
```json
{
  "title": "Demonstrasi API Client",
  "body": "Pengujian pengiriman request method POST dengan body JSON",
  "userId": 1
}
```
* **Hasil Response:**
  * **Status Code:** `201 Created`
  * **Response Body:**
```json
{
  "title": "Demonstrasi API Client",
  "body": "Pengujian pengiriman request method POST dengan body JSON",
  "userId": 1,
  "id": 101
}
```
*(Server otomatis memberikan ID baru `101` sebagai bukti data telah diproses)*.

---

## 3. Tugas 2: Identifikasi Status Code dan Response Header

### 3.1 Klasifikasi HTTP Status Code
Status code adalah kode numerik 3 digit yang dikirim server untuk menginformasikan hasil pemrosesan request:

| Rentang | Kategori | Arti & Contoh |
| :--- | :--- | :--- |
| **1xx** | *Informational* | Request diterima dan proses sedang berlangsung. |
| **2xx** | *Success* | Request berhasil diterima, dipahami, dan diproses dengan baik.<br>• `200 OK`: Request sukses dan resource dikembalikan.<br>• `201 Created`: Request sukses dan resource baru berhasil dibuat. |
| **3xx** | *Redirection* | Klien harus melakukan tindakan tambahan, seperti pengalihan URL (`301 Moved Permanently`). |
| **4xx** | *Client Error* | Kesalahan terjadi dari sisi pengirim (klien).<br>• `400 Bad Request`: Format data request salah.<br>• `401 Unauthorized`: Klien belum terautentikasi.<br>• `404 Not Found`: Resource / URL yang diminta tidak ditemukan di server. |
| **5xx** | *Server Error* | Server gagal memenuhi request yang valid karena terjadi error internal (`500 Internal Server Error`, `502 Bad Gateway`). |

---

### 3.2 Analisis Response Header
Response Headers memuat metadata terkait server, keamanan, tipe konten, dan pengelolaan cache. Berikut header riil yang didapatkan saat menguji `https://jsonplaceholder.typicode.com/posts/1`:

| Response Header Key | Nilai Riil (Observasi) | Penjelasan & Fungsi Teknis |
| :--- | :--- | :--- |
| `Content-Type` | `application/json; charset=utf-8` | Memberitahu klien bahwa body data berupa dokumen JSON dengan pengkodean karakter UTF-8. |
| `Server` | `cloudflare` | Menunjukkan bahwa request dilayani oleh infrastruktur reverse proxy / CDN Cloudflare. |
| `Cache-Control` | `max-age=43200` | Menginstruksikan browser/klien bahwa data aman disimpan dalam cache lokal selama 43.200 detik (12 jam). |
| `Content-Length` | `292` | Ukuran payload data response dalam satuan byte. |
| `Date` | `Sat, 24 Oct 2026 12:32:55 GMT` | Waktu persis saat server selesai memproses response. |
| `x-powered-by` | `Express` | Menandakan framework backend server dibangun menggunakan Node.js Express. |
| `x-ratelimit-remaining` | `3599999` | Jumlah kuota sisa pemanggilan request yang diperbolehkan sebelum terkena *rate limiting*. |

---

## 4. Tugas 3: Identifikasi Struktur Data JSON (Object, Array, Key-Value)

JSON (*JavaScript Object Notation*) adalah format pertukaran data berbasis teks yang ringan dan mudah dibaca oleh manusia maupun mesin.

### 4.1 Identifikasi Single Object
* **Endpoint:** `GET https://jsonplaceholder.typicode.com/posts/1`
* **Response Body:**
```json
{
  "userId": 1,
  "id": 1,
  "title": "sunt aut facere repellat provident occaecati excepturi optio reprehenderit",
  "body": "quia et suscipit\nsuscipit recusandae consequuntur expedita et cum\nreprehenderit molestiae ut ut quas totam\nnostrum rerum est autem sunt rem eveniet architecto"
}
```
* **Karakteristik Teknis:**
  1. **Object:** Seluruh data diapit oleh tanda kurung kurawal `{ }`. Ini merepresentasikan 1 entitas data postingan.
  2. **Key - Value Pair:** Terdiri dari pasangan kunci dan nilai yang dipisahkan oleh tanda titik dua `:`.
     * `"userId": 1` &rarr; Key: `userId`, Value: `1` (Tipe data: Integer/Number)
     * `"id": 1` &rarr; Key: `id`, Value: `1` (Tipe data: Integer/Number)
     * `"title": "..."` &rarr; Key: `title`, Value: string teks (Tipe data: String)
     * `"body": "..."` &rarr; Key: `body`, Value: string paragraf (Tipe data: String)

---

### 4.2 Identifikasi Array of Objects
* **Endpoint:** `GET https://jsonplaceholder.typicode.com/posts`
* **Response Body (Preview):**
```json
[
  {
    "userId": 1,
    "id": 1,
    "title": "sunt aut facere...",
    "body": "quia et suscipit..."
  },
  {
    "userId": 1,
    "id": 2,
    "title": "qui est esse",
    "body": "est rerum tempore..."
  }
  // ... total 100 objek
]
```
* **Karakteristik Teknis:**
  1. **Array:** Seluruh data diapit oleh kurung siku `[ ]`.
  2. **Koleksi Objek:** Di dalam array terdapat 100 objek postingan yang dipisahkan tanda koma `,`.
  3. **Akses Indeks:** Elemen pertama diakses melalui indeks ke-0 (`response[0]`), kedua pada indeks ke-1 (`response[1]`), dan seterusnya.

---

### 4.3 Identifikasi Nested Object (Objek Bersarang)
* **Endpoint:** `GET https://jsonplaceholder.typicode.com/users/1`
* **Response Body:**
```json
{
  "id": 1,
  "name": "Leanne Graham",
  "username": "Bret",
  "email": "Sincere@april.biz",
  "address": {
    "street": "Kulas Light",
    "suite": "Apt. 556",
    "city": "Gwenborough",
    "zipcode": "92998-3874",
    "geo": {
      "lat": "-37.3159",
      "lng": "81.1496"
    }
  },
  "company": {
    "name": "Romaguera-Crona",
    "catchPhrase": "Multi-layered client-server neural-net"
  }
}
```
* **Karakteristik Teknis:**
  * Properti `address` nilainya bukan string/angka, melainkan **objek baru** bertingkat.
  * Di dalam `address` terdapat sub-objek bersarang lagi yaitu `geo` (`geo.lat` dan `geo.lng`).
  * Pemanggilan nilai dilakukan secara berantai: `user.address.city` atau `user.address.geo.lat`.

---

## 5. Tugas 4: Pengujian Endpoint dengan ID Tersedia vs Tidak Tersedia

Pada tahap ini dilakukan perbandingan langsung untuk memverifikasi bagaimana API menangani request valid, request ke ID yang tidak ada, dan request ke route/path yang salah:

### 5.1 Tabel Perbandingan Hasil Uji

| Parameter Uji | Kasus A: ID Tersedia | Kasus B: ID Tidak Tersedia | Kasus C: Path Endpoint Salah |
| :--- | :--- | :--- | :--- |
| **Endpoint** | `GET /posts/1` | `GET /posts/9999` | `GET /postss/1` |
| **Status Code** | `200 OK` | `404 Not Found` | `404 Not Found` |
| **Content-Type** | `application/json` | `application/json` | `application/json` |
| **Ukuran Body** | 292 Bytes | 2 Bytes | 2 Bytes |
| **Isi Body** | Objek lengkap berisi data post (id, userId, title, body) | Objek kosong `{}` | Objek kosong `{}` |
| **Status Cache** | `HIT` | `HIT` | `EXPIRED` / `MISS` |

### 5.2 Analisis Teknis Perbedaan
1. **Kasus A (`/posts/1`):** Server menemukan ID `1` pada tabel/koleksi posts. Query basis data mengembalikan baris yang cocok, lalu diserialisasi menjadi format JSON lengkap dengan status HTTP `200 OK`.
2. **Kasus B (`/posts/9999`):** Endpoint route `/posts/:id` valid dan dikenali oleh router server. Namun, saat filter ID `9999` dilakukan pada basis data, hasilnya bernilai `null` / kosong. Server secara tepat merespon dengan status `404 Not Found` dan mengembalikan payload kosong `{}`.
3. **Kasus C (`/postss/1`):** Router Express pada backend tidak mendefinisikan routing untuk kata kunci jamak yang salah ketik (`/postss`). Server langsung mencegat request di tingkat router middleware dengan status `404 Not Found` sebelum sempat melakukan query database.

---

## 6. Tugas 5: Tabel Dokumentasi Pengujian Sistematis

Tabel ini dapat langsung disalin ke lembar tugas laporan (Microsoft Word atau Slide Presentasi):

| No | Skenario Pengujian | Method | Endpoint URL | Status Code | Content-Type | Hasil / Observasi | Ref. Gambar |
| :---: | :--- | :---: | :--- | :---: | :---: | :--- | :---: |
| **1** | Mengambil 1 data postingan dengan ID valid | `GET` | `/posts/1` | `200 OK` | `application/json` | Mengembalikan **JSON Object** lengkap dengan 4 key: `userId`, `id`, `title`, dan `body`. | *Screenshot 1* |
| **2** | Mengambil seluruh data postingan | `GET` | `/posts` | `200 OK` | `application/json` | Mengembalikan **JSON Array** berisi 100 objek data postingan. | *Screenshot 2* |
| **3** | Mengambil data user untuk analisis struktur bersarang | `GET` | `/users/1` | `200 OK` | `application/json` | Mengembalikan **Nested Object** dengan atribut bersarang `address` (dan sub `geo`) serta `company`. | *Screenshot 3* |
| **4** | Membuat postingan baru dengan mengirim payload body | `POST` | `/posts` | `201 Created` | `application/json` | Berhasil membuat entitas baru. Server mengembalikan objek dengan tambahan key id otomatis (`id: 101`). | *Screenshot 4* |
| **5** | Menguji pengambilan data dengan ID yang tidak terdaftar | `GET` | `/posts/9999` | `404 Not Found` | `application/json` | Server mengembalikan kode status 404 (Client Error) dengan body objek kosong `{}`. | *Screenshot 5* |
| **6** | Menguji request dengan penulisan path routing yang salah | `GET` | `/postss/1` | `404 Not Found` | `application/json` | Endpoint salah ketik (*invalid route*). Server merespon dengan status 404 Not Found. | *Screenshot 6* |

---

## 7. Panduan File Pendukung & Eksekusi

Di dalam folder proyek `d:\tugas\semester 5\Demontrasi API Client`, telah disiapkan 3 alat pendukung:

### 7.1 Koleksi Postman Siap Pakai (`jsonplaceholder_api_test_collection.json`)
* **Cara Import ke Postman:**
  1. Buka Postman.
  2. Klik tombol **Import** (di pojok kiri atas).
  3. Drag-and-drop file `jsonplaceholder_api_test_collection.json`.
  4. Semua 6 skenario request di atas akan langsung tersedia dan siap diklik `Send` untuk mengambil screenshot tugas.

### 7.2 Script Otomatisasi Terminal (`test-api.ps1`)
* Dapat dijalankan langsung dari terminal PowerShell untuk memverifikasi semua endpoint dalam 2 detik:
```powershell
powershell -ExecutionPolicy Bypass -File .\test-api.ps1
```

### 7.3 Dashboard Interaktif Web Client (`index.html`)
* Buka file `index.html` langsung di browser (klik dua kali atau buka via browser seperti Chrome/Edge).
* Dilengkapi antarmuka modern untuk melakukan live fetch request, visualisasi status badge, inspeksi response header, dan dekonstruksi struktur data JSON secara interaktif.
