# ==============================================================================
# Script Demonstrasi Pengujian API Publik (JSONPlaceholder)
# Matakuliah: Demonstrasi API Client - Semester 5
# Kompatibel dengan Windows PowerShell 5.1 & PowerShell Core 7
# ==============================================================================

Write-Host "=================================================================" -ForegroundColor Cyan
Write-Host "   DEMONSTRASI PENGUJIAN API PUBLIK (JSONPLACEHOLDER)" -ForegroundColor Yellow
Write-Host "=================================================================`n" -ForegroundColor Cyan

function Run-ApiTest {
    param(
        [int]$No,
        [string]$Scenario,
        [string]$Method,
        [string]$Url,
        [string]$Body = $null
    )

    Write-Host "[$No] $Scenario" -ForegroundColor White -BackgroundColor DarkBlue
    Write-Host "Method  : $Method" -ForegroundColor Magenta
    Write-Host "Endpoint: $Url" -ForegroundColor Gray
    if ($Body) {
        Write-Host "Body    : $Body" -ForegroundColor DarkCyan
    }

    try {
        $stopwatch = [System.Diagnostics.Stopwatch]::StartNew()
        $request = [System.Net.HttpWebRequest]::Create($Url)
        $request.Method = $Method
        $request.ContentType = "application/json; charset=utf-8"
        $request.UserAgent = "PowerShell-ApiClient/1.0"

        if ($Body -and ($Method -eq "POST" -or $Method -eq "PUT" -or $Method -eq "PATCH")) {
            $bytes = [System.Text.Encoding]::UTF8.GetBytes($Body)
            $request.ContentLength = $bytes.Length
            $requestStream = $request.GetRequestStream()
            $requestStream.Write($bytes, 0, $bytes.Length)
            $requestStream.Close()
        }

        $response = $null
        try {
            $response = $request.GetResponse()
        } catch [System.Net.WebException] {
            $response = $_.Exception.Response
        }

        $stopwatch.Stop()

        if ($response -ne $null) {
            $httpResponse = [System.Net.HttpWebResponse]$response
            $statusCode = [int]$httpResponse.StatusCode
            $statusDescription = $httpResponse.StatusDescription
            $statusColor = if ($statusCode -ge 200 -and $statusCode -lt 300) { "Green" } elseif ($statusCode -ge 400 -and $statusCode -lt 500) { "Red" } else { "Yellow" }

            Write-Host "`n--- RESPONSE HEADER & STATUS ---" -ForegroundColor DarkYellow
            Write-Host "Status Code : $statusCode $statusDescription ($($stopwatch.ElapsedMilliseconds) ms)" -ForegroundColor $statusColor
            Write-Host "Content-Type: $($httpResponse.ContentType)" -ForegroundColor Gray
            Write-Host "Server      : $($httpResponse.Headers['Server'])" -ForegroundColor Gray
            Write-Host "Cache-Ctrl  : $($httpResponse.Headers['Cache-Control'])" -ForegroundColor Gray

            $reader = New-Object System.IO.StreamReader($httpResponse.GetResponseStream())
            $rawContent = $reader.ReadToEnd()
            $reader.Close()
            $httpResponse.Close()

            Write-Host "`n--- RESPONSE BODY (PREVIEW) ---" -ForegroundColor DarkYellow
            if ($rawContent.Length -gt 400) {
                Write-Host ($rawContent.Substring(0, 400) + "... [Truncated, total $($rawContent.Length) chars]") -ForegroundColor Green
            } else {
                Write-Host $rawContent -ForegroundColor Green
            }
        }
    }
    catch {
        Write-Host "Error executing request: $_" -ForegroundColor Red
    }

    Write-Host "`n" + ("-" * 65) + "`n"
}

# 1. GET Single Post (ID Tersedia)
Run-ApiTest -No 1 -Scenario "Ambil 1 Post (ID Tersedia - JSON Object)" -Method "GET" -Url "https://jsonplaceholder.typicode.com/posts/1"

# 2. GET All Posts (Array of Objects)
Run-ApiTest -No 2 -Scenario "Ambil Seluruh Post (JSON Array of Objects)" -Method "GET" -Url "https://jsonplaceholder.typicode.com/posts"

# 3. GET User (Nested Object)
Run-ApiTest -No 3 -Scenario "Ambil Data User (Struktur Nested JSON Object)" -Method "GET" -Url "https://jsonplaceholder.typicode.com/users/1"

# 4. POST Create Post
Run-ApiTest -No 4 -Scenario "Membuat Post Baru (Method POST)" -Method "POST" -Url "https://jsonplaceholder.typicode.com/posts" -Body '{"title":"Tugas API Client","body":"Demonstrasi method POST semester 5","userId":1}'

# 5. GET Post ID Tidak Ada
Run-ApiTest -No 5 -Scenario "Ambil Post dengan ID Tidak Tersedia (404 Not Found)" -Method "GET" -Url "https://jsonplaceholder.typicode.com/posts/9999"

# 6. GET Invalid Path
Run-ApiTest -No 6 -Scenario "Request ke Endpoint Path Salah (404 Not Found)" -Method "GET" -Url "https://jsonplaceholder.typicode.com/postss/1"

Write-Host "Pengujian selesai! Semua skenario berhasil dieksekusi.`n" -ForegroundColor Green
